/* Automatically generated - do not edit */
#include <configs/smdkc100.h>
